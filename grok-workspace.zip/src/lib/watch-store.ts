import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ProfileId = "jiyyad" | "keluarga" | "anak";

export type Profile = {
  id: ProfileId;
  name: string;
  tone: "primary" | "ink" | "soft";
  note: string;
};

export const PROFILES: Profile[] = [
  { id: "jiyyad", name: "Jiyyad", tone: "primary", note: "Semua judul" },
  { id: "keluarga", name: "Keluarga", tone: "ink", note: "Bersama di sofa" },
  { id: "anak", name: "Anak", tone: "soft", note: "Tanpa 17+ & horor" },
];

type WatchState = {
  profileId: ProfileId | null;
  myList: string[];
  progress: Record<string, number>;
  setProfile: (id: ProfileId | null) => void;
  toggleList: (id: string) => void;
  setProgress: (id: string, value: number) => void;
};

export const useWatch = create<WatchState>()(
  persist(
    (set) => ({
      profileId: null,
      myList: [],
      progress: {},
      setProfile: (profileId) => set({ profileId }),
      toggleList: (id) =>
        set((state) => ({
          myList: state.myList.includes(id)
            ? state.myList.filter((item) => item !== id)
            : [id, ...state.myList],
        })),
      setProgress: (id, value) =>
        set((state) => ({
          progress: {
            ...state.progress,
            [id]: Math.min(1, Math.max(0, value)),
          },
        })),
    }),
    {
      name: "adflix-watch",
      merge: (persistedState, currentState) => {
        const persisted = (persistedState ?? {}) as Partial<WatchState>;
        return {
          ...currentState,
          ...persisted,
          profileId: currentState.profileId ?? persisted.profileId ?? null,
          myList: currentState.myList.length ? currentState.myList : (persisted.myList ?? []),
          progress: { ...(persisted.progress ?? {}), ...currentState.progress },
        };
      },
    },
  ),
);
