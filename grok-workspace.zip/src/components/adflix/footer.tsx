import { useState } from "react";

const NOTES: { label: string; body: string }[] = [
  {
    label: "Tentang ADFLIX",
    body: "ADFLIX adalah layanan tontonan orisinal milik jiyyad tools. Semua judul, tokoh, dan gambar di katalog ini fiksi — dibuat untuk ditonton di peramban, bukan salinan karya pihak lain.",
  },
  {
    label: "Profil",
    body: "Profil Jiyyad, Keluarga, dan Anak tersimpan di perangkat ini. Profil Anak menyembunyikan judul 17+ dan horor. Tidak ada akun yang perlu dibuat.",
  },
  {
    label: "Audio & subtitle",
    body: "Antarmuka berbahasa Indonesia. Pratinjau pemutar bersifat sinematik dan tanpa suara — garis waktu, intro, dan episode tetap bisa dijelajahi.",
  },
  {
    label: "Bantuan",
    body: "Cari dengan ikon kaca pembesar atau tombol garis miring. Tambahkan judul ke Daftar Saya, lalu lanjutkan dari baris Lanjutkan menonton setelah kamu menekan Putar.",
  },
];

export function Footer() {
  const [open, setOpen] = useState<string | null>(null);
  const note = NOTES.find((item) => item.label === open);

  return (
    <footer className="mt-10 border-t border-line px-4 py-10 text-sm text-faint sm:px-10 lg:px-14">
      <p className="text-base text-muted">Ada pertanyaan? Ini meja jiyyad tools.</p>
      <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {NOTES.map((item) => (
          <li key={item.label}>
            <button
              type="button"
              onClick={() => setOpen(item.label)}
              className="text-left text-muted underline-offset-4 hover:text-fg hover:underline"
            >
              {item.label}
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-8 text-xs">© 2026 jiyyad tools. ADFLIX.</p>
      {note ? (
        <div
          className="fixed inset-0 z-50 grid place-items-end bg-bg-deep/70 sm:place-items-center"
          onClick={() => setOpen(null)}
        >
          <div
            className="w-full max-w-md rounded-t-card bg-surface p-6 sm:rounded-card"
            onClick={(event) => event.stopPropagation()}
            role="dialog"
            aria-label={note.label}
          >
            <h2 className="text-lg font-semibold text-fg">{note.label}</h2>
            <p className="mt-3 text-pretty text-sm leading-relaxed text-muted">{note.body}</p>
            <button
              type="button"
              onClick={() => setOpen(null)}
              className="mt-5 h-11 rounded-md bg-play px-5 text-sm font-bold text-play-fg"
            >
              Tutup
            </button>
          </div>
        </div>
      ) : null}
    </footer>
  );
}
