import { Logo } from "@/components/adflix/logo";
import { PROFILES, type Profile, type ProfileId } from "@/lib/watch-store";

const toneClass: Record<Profile["tone"], string> = {
  primary: "bg-primary text-fg",
  ink: "bg-surface-2 text-fg",
  soft: "bg-fg text-play-fg",
};

export function Profiles({ onPick }: { onPick: (id: ProfileId) => void }) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-bg px-6 py-16">
      <Logo className="mb-10 text-5xl sm:text-6xl" />
      <h1 className="text-balance text-center text-3xl font-medium text-fg sm:text-5xl">
        Siapa yang menonton?
      </h1>
      <p className="mt-3 text-center text-sm text-muted sm:text-base">
        Pilih profil. Daftar dan progres tersimpan di perangkat ini.
      </p>
      <ul className="mt-10 grid w-full max-w-3xl grid-cols-3 gap-3 sm:gap-8">
        {PROFILES.map((profile) => (
          <li key={profile.id} className="flex justify-center">
            <button
              type="button"
              onClick={() => onPick(profile.id)}
              className="group flex w-full max-w-40 flex-col items-center gap-3 rounded-card focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-fg"
            >
              <span
                className={`grid aspect-square w-full place-items-center rounded-card font-display text-5xl transition duration-200 group-hover:ring-2 group-hover:ring-fg sm:text-7xl ${toneClass[profile.tone]}`}
              >
                {profile.name.slice(0, 1)}
              </span>
              <span className="text-center text-sm text-muted transition group-hover:text-fg sm:text-lg">
                {profile.name}
              </span>
              <span className="hidden text-center text-xs text-faint sm:block">{profile.note}</span>
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-14 text-center text-sm text-faint">
        ADFLIX · layanan tontonan oleh <span className="text-muted">jiyyad tools</span>
      </p>
    </main>
  );
}
