import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { TitleItem } from "@/data/catalog";

export function TitleCard({
  title,
  rank,
  progress,
  onOpen,
}: {
  title: TitleItem;
  rank?: number;
  progress?: number;
  onOpen: (id: string) => void;
}) {
  return (
    <div className="flex w-full items-end">
      {rank ? (
        <span className="rank-num -mr-2 mb-1 shrink-0 select-none">{rank}</span>
      ) : null}
      <button
        type="button"
        onClick={() => onOpen(title.id)}
        className="group relative aspect-[2/3] w-full min-w-0 overflow-hidden rounded-card bg-surface text-left shadow-lg ring-1 ring-transparent transition duration-200 hover:-translate-y-1 hover:ring-fg/70"
      >
        <img
          src={title.poster}
          alt={title.name}
          className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
        />
        <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg-deep via-bg-deep/80 to-transparent px-2 pt-12 pb-2">
          <span className="line-clamp-2 block text-xs font-semibold text-fg sm:text-sm">
            {title.name}
          </span>
        </span>
        {typeof progress === "number" ? (
          <span className="absolute inset-x-0 bottom-0 h-1 bg-line">
            <span
              className="block h-full bg-primary"
              style={{ width: `${Math.round(progress * 100)}%` }}
            />
          </span>
        ) : null}
      </button>
    </div>
  );
}

export function Row({
  title,
  items,
  onOpen,
  ranked = false,
  progressOf,
}: {
  title: string;
  items: TitleItem[];
  onOpen: (id: string) => void;
  ranked?: boolean;
  progressOf?: (id: string) => number | undefined;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  if (items.length === 0) return null;

  const move = (direction: number) => {
    const node = scroller.current;
    if (!node) return;
    node.scrollBy({ left: direction * node.clientWidth * 0.75, behavior: "smooth" });
  };

  return (
    <section className="relative mt-2 mb-6 sm:mt-4">
      <div className="mb-2 flex items-end justify-between px-4 sm:px-10 lg:px-14">
        <h2 className="text-lg font-semibold text-fg sm:text-xl">{title}</h2>
      </div>
      <div className="group/row relative">
        <button
          type="button"
          aria-label="Geser kiri"
          onClick={() => move(-1)}
          className="absolute top-1/2 left-2 z-10 hidden size-11 -translate-y-1/2 place-items-center rounded-full bg-bg/80 text-fg ring-1 ring-line sm:grid sm:opacity-0 sm:transition sm:group-hover/row:opacity-100"
        >
          <ChevronLeft className="size-6" />
        </button>
        <div
          ref={scroller}
          className="no-scrollbar flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 py-3 sm:px-10 sm:py-4 lg:px-14"
        >
          {items.map((item, index) => (
            <div
              key={item.id}
              className={ranked ? "w-52 shrink-0 snap-start sm:w-64" : "w-32 shrink-0 snap-start sm:w-44"}
            >
              <TitleCard
                title={item}
                rank={ranked ? index + 1 : undefined}
                progress={progressOf?.(item.id)}
                onOpen={onOpen}
              />
            </div>
          ))}
        </div>
        <button
          type="button"
          aria-label="Geser kanan"
          onClick={() => move(1)}
          className="absolute top-1/2 right-2 z-10 hidden size-11 -translate-y-1/2 place-items-center rounded-full bg-bg/80 text-fg ring-1 ring-line sm:grid sm:opacity-0 sm:transition sm:group-hover/row:opacity-100"
        >
          <ChevronRight className="size-6" />
        </button>
      </div>
    </section>
  );
}

export function PosterGrid({
  items,
  onOpen,
  progressOf,
  empty,
}: {
  items: TitleItem[];
  onOpen: (id: string) => void;
  progressOf?: (id: string) => number | undefined;
  empty?: string;
}) {
  if (items.length === 0) {
    return (
      <div className="mx-4 rounded-card border border-line bg-surface px-6 py-16 text-center sm:mx-10 lg:mx-14">
        <p className="text-lg font-semibold">{empty ?? "Belum ada judul di sini."}</p>
        <p className="mt-2 text-sm text-muted">
          Jelajahi beranda, atau ganti profil bila katalognya disaring.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 sm:px-10 md:grid-cols-4 lg:grid-cols-5 lg:px-14">
      {items.map((item) => (
        <TitleCard
          key={item.id}
          title={item}
          onOpen={onOpen}
          progress={progressOf?.(item.id)}
        />
      ))}
    </div>
  );
}
