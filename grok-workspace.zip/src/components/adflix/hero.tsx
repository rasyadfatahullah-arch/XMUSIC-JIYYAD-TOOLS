import { Check, Info, Play, Plus } from "lucide-react";
import type { TitleItem } from "@/data/catalog";

export function Hero({
  titles,
  index,
  onIndex,
  inList,
  onPlay,
  onInfo,
  onToggleList,
}: {
  titles: TitleItem[];
  index: number;
  onIndex: (index: number) => void;
  inList: boolean;
  onPlay: (id: string) => void;
  onInfo: (id: string) => void;
  onToggleList: (id: string) => void;
}) {
  const title = titles[index] ?? titles[0];
  if (!title) return null;

  return (
    <section className="relative h-[100svh] overflow-hidden sm:h-[92svh]">
      <img
        key={title.id}
        src={title.poster}
        alt=""
        className="hero-drift absolute inset-0 h-full w-full object-cover object-[center_18%]"
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-bg via-bg/80 to-bg/15" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-bg via-bg/20 to-bg/40" />
      <div className="absolute inset-x-0 bottom-0 max-w-3xl px-4 pt-28 pb-8 sm:px-10 sm:pb-14 lg:px-14">
        <p className="text-xs font-semibold tracking-widest text-fg/80 uppercase">
          {title.original ? "Hanya di ADFLIX" : "Pilihan ADFLIX"} ·{" "}
          {title.kind === "series" ? "Serial" : "Film"}
        </p>
        <h1 className="mt-2 max-w-xl text-balance font-display text-5xl leading-none tracking-wide text-fg sm:text-7xl lg:text-8xl">
          {title.name}
        </h1>
        <p className="mt-3 text-lg font-medium text-fg sm:text-xl">{title.tagline}</p>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-sm text-muted">
          <span className="font-semibold text-fg tabular-nums">{title.match}% cocok</span>
          <span>{title.year}</span>
          <span className="rounded-card border border-line px-1.5 py-0.5 text-xs text-fg">
            {title.rating}
          </span>
          <span>
            {title.kind === "series"
              ? `${title.seasons} musim`
              : `${Math.floor(title.minutes / 60)}j ${title.minutes % 60}m`}
          </span>
          <span className="rounded-card border border-line px-1.5 py-0.5 text-xs text-fg">HD</span>
        </div>
        <p className="mt-4 line-clamp-2 max-w-xl text-pretty text-sm text-fg/90 sm:line-clamp-3 sm:text-base">{title.synopsis}</p>
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => onPlay(title.id)}
            className="inline-flex h-12 items-center gap-2 rounded-md bg-play px-6 text-base font-bold text-play-fg transition hover:bg-play/85"
          >
            <Play className="size-5 fill-current" />
            Putar
          </button>
          <button
            type="button"
            onClick={() => onInfo(title.id)}
            className="inline-flex h-12 items-center gap-2 rounded-md bg-surface-2/80 px-5 text-base font-semibold text-fg ring-1 ring-line backdrop-blur-sm transition hover:bg-surface-2"
          >
            <Info className="size-5" />
            Info lainnya
          </button>
          <button
            type="button"
            onClick={() => onToggleList(title.id)}
            className="grid size-12 place-items-center rounded-full border border-line bg-bg/50 text-fg backdrop-blur-sm hover:border-fg"
            aria-label={inList ? "Hapus dari Daftar Saya" : "Tambah ke Daftar Saya"}
          >
            {inList ? <Check className="size-5" /> : <Plus className="size-5" />}
          </button>
        </div>
        {titles.length > 1 ? (
          <div className="mt-8 flex gap-2" role="tablist" aria-label="Judul unggulan">
            {titles.map((item, itemIndex) => (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={itemIndex === index}
                aria-label={item.name}
                onClick={() => onIndex(itemIndex)}
                className={`h-1.5 rounded-pill transition-all ${
                  itemIndex === index ? "w-8 bg-fg" : "w-4 bg-fg/35 hover:bg-fg/60"
                }`}
              />
            ))}
          </div>
        ) : null}
      </div>
    </section>
  );
}
