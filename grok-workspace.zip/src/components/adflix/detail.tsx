import { Link } from "@tanstack/react-router";
import { Check, Play, Plus, X } from "lucide-react";
import { similarTo, type TitleItem } from "@/data/catalog";
import { TitleCard } from "@/components/adflix/row";

function metaLine(title: TitleItem) {
  if (title.kind === "series") {
    return `${title.seasons} musim · ${title.minutes} mnt/episode`;
  }
  const hours = Math.floor(title.minutes / 60);
  const mins = title.minutes % 60;
  return `${hours}j ${mins}m`;
}

export function Detail({
  title,
  pool,
  inList,
  onClose,
  onOpen,
  onToggleList,
}: {
  title: TitleItem;
  pool: TitleItem[];
  inList: boolean;
  onClose: () => void;
  onOpen: (id: string) => void;
  onToggleList: (id: string) => void;
}) {
  const related = similarTo(title, pool);

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-bg-deep/80"
      role="dialog"
      aria-modal="true"
      aria-label={title.name}
      onClick={onClose}
    >
      <div
        className="mx-auto min-h-screen w-full max-w-4xl bg-surface sm:my-8 sm:min-h-0 sm:overflow-hidden sm:rounded-card"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="relative h-80 sm:h-[28rem]">
          <img
            src={title.poster}
            alt=""
            className="h-full w-full object-cover object-[center_20%]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/20 to-bg-deep/30" />
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 grid size-11 place-items-center rounded-full bg-bg/80 text-fg ring-1 ring-line"
            aria-label="Tutup"
          >
            <X className="size-5" />
          </button>
          <div className="absolute inset-x-0 bottom-0 px-5 pb-5 sm:px-8">
            <p className="text-xs font-semibold tracking-widest text-fg/80 uppercase">
              {title.original ? "ADFLIX Original" : "Koleksi ADFLIX"}
            </p>
            <h2 className="font-display text-5xl leading-none tracking-wide sm:text-7xl">{title.name}</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link
                to="/watch/$id"
                params={{ id: title.id }}
                search={{ ep: 1 }}
                className="inline-flex h-12 items-center gap-2 rounded-md bg-play px-5 text-base font-bold text-play-fg"
              >
                <Play className="size-5 fill-current" />
                Putar
              </Link>
              <button
                type="button"
                onClick={() => onToggleList(title.id)}
                className="inline-flex h-12 items-center gap-2 rounded-md bg-surface-2 px-4 text-sm font-semibold ring-1 ring-line"
              >
                {inList ? <Check className="size-4" /> : <Plus className="size-4" />}
                {inList ? "Di Daftar Saya" : "Daftar Saya"}
              </button>
            </div>
          </div>
        </div>
        <div className="grid gap-6 px-5 py-6 sm:grid-cols-[1.4fr_0.8fr] sm:px-8">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-sm text-muted">
              <span className="font-semibold text-fg tabular-nums">{title.match}% cocok</span>
              <span>{title.year}</span>
              <span className="rounded-card border border-line px-1.5 text-xs text-fg">{title.rating}</span>
              <span>{metaLine(title)}</span>
            </div>
            <p className="mt-3 text-pretty text-sm leading-relaxed text-fg sm:text-base">{title.synopsis}</p>
          </div>
          <dl className="space-y-3 text-sm">
            <div>
              <dt className="text-faint">Pemain</dt>
              <dd className="text-fg">{title.cast.join(", ")}</dd>
            </div>
            <div>
              <dt className="text-faint">Genre</dt>
              <dd className="text-fg">{title.genres.join(" · ")}</dd>
            </div>
            <div>
              <dt className="text-faint">Tayang</dt>
              <dd className="text-fg">ADFLIX · jiyyad tools</dd>
            </div>
          </dl>
        </div>
        {title.episodes ? (
          <div className="px-5 pb-6 sm:px-8">
            <h3 className="mb-3 text-lg font-semibold">Episode</h3>
            <ol className="divide-y divide-line border-y border-line">
              {title.episodes.map((episode) => (
                <li key={episode.n}>
                  <Link
                    to="/watch/$id"
                    params={{ id: title.id }}
                    search={{ ep: episode.n }}
                    className="flex items-start gap-4 py-4 hover:bg-surface-2/60"
                  >
                    <span className="w-6 pt-1 text-xl font-semibold text-muted tabular-nums">
                      {episode.n}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-baseline justify-between gap-3">
                        <span className="font-semibold">{episode.title}</span>
                        <span className="shrink-0 text-xs text-muted tabular-nums">{episode.minutes} mnt</span>
                      </span>
                      <span className="mt-1 block text-sm text-pretty text-muted">{episode.blurb}</span>
                    </span>
                    <Play className="mt-1 size-4 shrink-0 fill-current" />
                  </Link>
                </li>
              ))}
            </ol>
          </div>
        ) : null}
        {related.length > 0 ? (
          <div className="px-5 pb-8 sm:px-8">
            <h3 className="mb-3 text-lg font-semibold">Lebih seperti ini</h3>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {related.slice(0, 4).map((item) => (
                <TitleCard key={item.id} title={item} onOpen={onOpen} />
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
