export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`font-display tracking-widest text-primary leading-none ${className}`}>
      ADFLIX
    </span>
  );
}
