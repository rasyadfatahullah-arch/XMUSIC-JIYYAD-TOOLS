import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search, X } from "lucide-react";
import { forViewer, type TitleItem } from "@/data/catalog";
import { useWatch, type ProfileId } from "@/lib/watch-store";
import { Header, type Section } from "@/components/adflix/header";
import { Hero } from "@/components/adflix/hero";
import { PosterGrid, Row } from "@/components/adflix/row";
import { Detail } from "@/components/adflix/detail";
import { Footer } from "@/components/adflix/footer";

function hasGenre(title: TitleItem, genres: string[]) {
  return title.genres.some((genre) => genres.includes(genre));
}

export function Browse({ profileId }: { profileId: ProfileId }) {
  const navigate = useNavigate();
  const kids = profileId === "anak";
  const pool = useMemo(() => forViewer(kids), [kids]);
  const myList = useWatch((state) => state.myList);
  const progress = useWatch((state) => state.progress);
  const toggleList = useWatch((state) => state.toggleList);
  const setProfile = useWatch((state) => state.setProfile);

  const [section, setSection] = useState<Section>("home");
  const [feature, setFeature] = useState(0);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [toast, setToast] = useState<string | null>(null);

  const featured = pool.filter((title) => title.featured);
  const spotlight = featured.length > 0 ? featured : pool.slice(0, 1);
  const safeFeature = spotlight.length ? feature % spotlight.length : 0;
  const active = pool.find((title) => title.id === activeId) ?? null;

  useEffect(() => {
    if (section !== "home" || searchOpen || active) return;
    const timer = window.setInterval(() => {
      setFeature((current) => current + 1);
    }, 8000);
    return () => window.clearInterval(timer);
  }, [section, searchOpen, active, spotlight.length]);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = active || searchOpen ? "hidden" : previous;
    return () => {
      document.body.style.overflow = previous;
    };
  }, [active, searchOpen]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") {
        if (event.key === "Escape") setSearchOpen(false);
        return;
      }
      if (event.key === "/") {
        event.preventDefault();
        setSearchOpen(true);
      }
      if (event.key === "Escape") {
        setActiveId(null);
        setSearchOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const play = (id: string) => {
    void navigate({ to: "/watch/$id", params: { id }, search: { ep: 1 } });
  };

  const onToggle = (id: string) => {
    const had = useWatch.getState().myList.includes(id);
    toggleList(id);
    setToast(had ? "Dihapus dari Daftar Saya" : "Masuk ke Daftar Saya");
    window.setTimeout(() => setToast(null), 1600);
  };

  const saved = myList
    .map((id) => pool.find((title) => title.id === id))
    .filter((title): title is TitleItem => Boolean(title));

  const continueWatching = pool.filter((title) => {
    const value = progress[title.id] ?? 0;
    return value > 0.02 && value < 0.98;
  });

  const trending = [...pool].sort((a, b) => b.match - a.match);
  const thrill = pool.filter((title) =>
    hasGenre(title, ["Kejahatan", "Thriller", "Horor", "Aksi"]),
  );
  const beyond = pool.filter((title) => hasGenre(title, ["Fiksi Ilmiah", "Fantasi", "Misteri"]));
  const easy = pool.filter((title) => hasGenre(title, ["Keluarga", "Olahraga", "Drama", "Romansa"]));
  const originals = pool.filter((title) => title.original);
  const fresh = [...pool].sort((a, b) => b.year - a.year || b.match - a.match);

  const results = pool.filter((title) => {
    const haystack = [title.name, title.tagline, title.synopsis, ...title.genres, ...title.cast]
      .join(" ")
      .toLowerCase();
    return haystack.includes(query.trim().toLowerCase());
  });

  const progressOf = (id: string) => {
    const value = progress[id];
    return value && value > 0.02 ? value : undefined;
  };

  return (
    <div className="min-h-screen bg-bg pb-8">
      <Header
        section={section}
        onSection={(next) => {
          setSection(next);
          setSearchOpen(false);
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        onSearch={() => setSearchOpen(true)}
        onSwitchProfile={() => setProfile(null)}
        profileId={profileId}
        fresh={fresh.slice(0, 4)}
        onOpen={setActiveId}
      />

      {section === "home" ? (
        <>
          <Hero
            titles={spotlight}
            index={safeFeature}
            onIndex={setFeature}
            inList={spotlight[safeFeature] ? myList.includes(spotlight[safeFeature].id) : false}
            onPlay={play}
            onInfo={setActiveId}
            onToggleList={onToggle}
          />
          <Row
            title="Lanjutkan menonton"
            items={continueWatching}
            onOpen={setActiveId}
            progressOf={progressOf}
          />
          <Row title="Sedang tren hari ini" items={trending} onOpen={setActiveId} ranked />
          <Row title="Hanya di ADFLIX" items={originals} onOpen={setActiveId} />
          <Row title="Yang bikin melek" items={thrill} onOpen={setActiveId} />
          <Row title="Di luar bumi" items={beyond} onOpen={setActiveId} />
          <Row title="Malam yang lebih tenang" items={easy} onOpen={setActiveId} />
        </>
      ) : (
        <div className="px-4 pt-32 pb-6 sm:px-10 sm:pt-28 lg:px-14">
          <h1 className="font-display text-5xl tracking-wide sm:text-6xl">
            {section === "series"
              ? "Serial"
              : section === "films"
                ? "Film"
                : section === "new"
                  ? "Baru & Populer"
                  : "Daftar Saya"}
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted sm:text-base">
            {section === "list"
              ? "Judul yang kamu simpan di perangkat ini."
              : section === "new"
                ? "Rilis terbaru di rak ADFLIX."
                : kids
                  ? "Profil Anak hanya menampilkan judul yang lebih ringan."
                  : "Katalog orisinal ADFLIX oleh jiyyad tools."}
          </p>
        </div>
      )}

      {section === "series" ? (
        <PosterGrid
          items={pool.filter((title) => title.kind === "series")}
          onOpen={setActiveId}
          progressOf={progressOf}
        />
      ) : null}
      {section === "films" ? (
        <PosterGrid
          items={pool.filter((title) => title.kind === "film")}
          onOpen={setActiveId}
          progressOf={progressOf}
        />
      ) : null}
      {section === "new" ? (
        <PosterGrid items={fresh} onOpen={setActiveId} progressOf={progressOf} />
      ) : null}
      {section === "list" ? (
        <PosterGrid
          items={saved}
          onOpen={setActiveId}
          progressOf={progressOf}
          empty="Daftar Saya masih kosong."
        />
      ) : null}

      <Footer />

      {active ? (
        <Detail
          title={active}
          pool={pool}
          inList={myList.includes(active.id)}
          onClose={() => setActiveId(null)}
          onOpen={setActiveId}
          onToggleList={onToggle}
        />
      ) : null}

      {searchOpen ? (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-bg">
          <div className="sticky top-0 flex items-center gap-3 border-b border-line bg-bg px-4 py-3 sm:px-10">
            <Search className="size-5 shrink-0 text-muted" />
            <input
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Judul, genre, atau pemain"
              className="h-12 w-full bg-transparent text-lg text-fg outline-none placeholder:text-faint"
              aria-label="Cari katalog"
            />
            <button
              type="button"
              onClick={() => {
                setSearchOpen(false);
                setQuery("");
              }}
              className="grid size-11 shrink-0 place-items-center rounded-full hover:bg-surface"
              aria-label="Tutup pencarian"
            >
              <X className="size-5" />
            </button>
          </div>
          <div className="py-6">
            {query.trim() ? (
              <PosterGrid
                items={results}
                onOpen={(id) => {
                  setSearchOpen(false);
                  setActiveId(id);
                }}
                empty={`Tidak ada hasil untuk “${query.trim()}”.`}
              />
            ) : (
              <div className="px-4 sm:px-10">
                <p className="text-sm text-muted">Coba “pelabuhan”, “fantasi”, atau “Laila”.</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {["Kejahatan", "Fantasi", "Fiksi Ilmiah", "Keluarga", "Thriller"].map((genre) => (
                    <button
                      key={genre}
                      type="button"
                      onClick={() => setQuery(genre)}
                      className="h-10 rounded-pill border border-line px-4 text-sm text-fg hover:border-fg"
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      ) : null}

      {toast ? (
        <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-pill bg-fg px-4 py-2 text-sm font-semibold text-play-fg shadow-lg">
          {toast}
        </div>
      ) : null}
    </div>
  );
}
