import { useEffect, useState } from "react";
import { Bell, Search, ChevronDown } from "lucide-react";
import { Logo } from "@/components/adflix/logo";
import type { TitleItem } from "@/data/catalog";
import { PROFILES, type ProfileId } from "@/lib/watch-store";

export type Section = "home" | "series" | "films" | "new" | "list";

const LINKS: { id: Section; label: string }[] = [
  { id: "home", label: "Beranda" },
  { id: "series", label: "Serial" },
  { id: "films", label: "Film" },
  { id: "new", label: "Baru & Populer" },
  { id: "list", label: "Daftar Saya" },
];

export function Header({
  section,
  onSection,
  onSearch,
  onSwitchProfile,
  profileId,
  fresh,
  onOpen,
}: {
  section: Section;
  onSection: (section: Section) => void;
  onSearch: () => void;
  onSwitchProfile: () => void;
  profileId: ProfileId;
  fresh: TitleItem[];
  onOpen: (id: string) => void;
}) {
  const [solid, setSolid] = useState(false);
  const [menu, setMenu] = useState<"bell" | "profile" | null>(null);
  const profile = PROFILES.find((item) => item.id === profileId) ?? PROFILES[0];

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const tone =
    profile.tone === "primary"
      ? "bg-primary text-fg"
      : profile.tone === "soft"
        ? "bg-fg text-play-fg"
        : "bg-surface-2 text-fg";

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-colors duration-300 ${
        solid ? "bg-bg/95 backdrop-blur-md" : "bg-gradient-to-b from-bg via-bg/70 to-transparent"
      }`}
    >
      <div className="flex items-center gap-4 px-4 py-3 sm:px-10">
        <button type="button" onClick={() => onSection("home")} aria-label="ADFLIX beranda">
          <Logo className="text-3xl sm:text-4xl" />
        </button>
        <nav className="hidden items-center gap-4 md:flex" aria-label="Utama">
          {LINKS.map((link) => (
            <button
              key={link.id}
              type="button"
              onClick={() => onSection(link.id)}
              className={`text-sm transition ${
                section === link.id ? "font-semibold text-fg" : "text-muted hover:text-fg"
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={onSearch}
            className="grid size-11 place-items-center rounded-full text-fg hover:bg-surface"
            aria-label="Cari"
          >
            <Search className="size-5" />
          </button>
          <div className="relative">
            <button
              type="button"
              onClick={() => setMenu((open) => (open === "bell" ? null : "bell"))}
              className="grid size-11 place-items-center rounded-full text-fg hover:bg-surface"
              aria-label="Baru masuk"
              aria-expanded={menu === "bell"}
            >
              <Bell className="size-5" />
            </button>
            {menu === "bell" ? (
              <div className="absolute right-0 mt-2 w-72 overflow-hidden rounded-card border border-line bg-surface shadow-2xl">
                <p className="border-b border-line px-4 py-3 text-xs font-semibold tracking-wide text-muted uppercase">
                  Baru di ADFLIX
                </p>
                <ul>
                  {fresh.map((title) => (
                    <li key={title.id}>
                      <button
                        type="button"
                        onClick={() => {
                          setMenu(null);
                          onOpen(title.id);
                        }}
                        className="flex w-full items-center gap-3 px-3 py-2 text-left hover:bg-surface-2"
                      >
                        <img
                          src={title.poster}
                          alt=""
                          className="h-14 w-10 rounded-card object-cover"
                        />
                        <span>
                          <span className="block text-sm font-semibold">{title.name}</span>
                          <span className="block text-xs text-muted">
                            {title.year} · {title.kind === "series" ? "Serial" : "Film"}
                          </span>
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
          <div className="relative">
            <button
              type="button"
              onClick={() => setMenu((open) => (open === "profile" ? null : "profile"))}
              className="flex items-center gap-1 rounded-full py-1 pr-1 pl-1 hover:bg-surface"
              aria-label="Profil"
              aria-expanded={menu === "profile"}
            >
              <span className={`grid size-8 place-items-center rounded-card font-display text-lg ${tone}`}>
                {profile.name.slice(0, 1)}
              </span>
              <ChevronDown className="hidden size-4 text-fg sm:block" />
            </button>
            {menu === "profile" ? (
              <div className="absolute right-0 mt-2 w-56 overflow-hidden rounded-card border border-line bg-surface shadow-2xl">
                <p className="px-4 pt-3 text-sm font-semibold">{profile.name}</p>
                <p className="px-4 pb-3 text-xs text-muted">jiyyad tools</p>
                <button
                  type="button"
                  onClick={() => {
                    setMenu(null);
                    onSwitchProfile();
                  }}
                  className="w-full border-t border-line px-4 py-3 text-left text-sm hover:bg-surface-2"
                >
                  Ganti profil
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </div>
      <nav className="no-scrollbar flex gap-4 overflow-x-auto px-4 pb-3 md:hidden" aria-label="Utama">
        {LINKS.map((link) => (
          <button
            key={link.id}
            type="button"
            onClick={() => onSection(link.id)}
            className={`shrink-0 text-sm ${
              section === link.id ? "font-semibold text-fg" : "text-muted"
            }`}
          >
            {link.label}
          </button>
        ))}
      </nav>
    </header>
  );
}
