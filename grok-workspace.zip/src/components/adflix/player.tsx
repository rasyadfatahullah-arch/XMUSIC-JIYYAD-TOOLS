import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Maximize, Pause, Play, RotateCcw, SkipForward, VolumeX } from "lucide-react";
import { getTitle } from "@/data/catalog";
import { useWatch } from "@/lib/watch-store";
import { Logo } from "@/components/adflix/logo";

const PREVIEW_SECONDS = 84;

function clock(progress: number) {
  const current = Math.min(PREVIEW_SECONDS, Math.floor(progress * PREVIEW_SECONDS));
  const format = (value: number) => {
    const minutes = Math.floor(value / 60);
    const seconds = value % 60;
    return `${minutes}:${String(seconds).padStart(2, "0")}`;
  };
  return `${format(current)} / ${format(PREVIEW_SECONDS)}`;
}

export function Player({ id, episode }: { id: string; episode: number }) {
  const navigate = useNavigate();
  const title = getTitle(id);
  const profileId = useWatch((state) => state.profileId);
  const saved = useWatch((state) => state.progress[id] ?? 0);
  const setProgress = useWatch((state) => state.setProgress);
  const shell = useRef<HTMLDivElement>(null);
  const progressRef = useRef(saved > 0.98 ? 0 : saved);
  const [local, setLocal] = useState(progressRef.current);
  const [playing, setPlaying] = useState(true);
  const [seek, setSeek] = useState(0);
  const [chrome, setChrome] = useState(true);
  const [episodeIndex, setEpisodeIndex] = useState(episode);

  useEffect(() => {
    if (profileId === null && useWatch.persist.hasHydrated()) {
      void navigate({ to: "/" });
    }
  }, [profileId, navigate]);

  useEffect(() => {
    setEpisodeIndex(episode);
  }, [episode]);

  useEffect(() => {
    if (!playing) return;
    const origin = progressRef.current;
    const started = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const next = Math.min(1, origin + (now - started) / 1000 / PREVIEW_SECONDS);
      progressRef.current = next;
      setLocal(next);
      if (next < 1) frame = requestAnimationFrame(tick);
      else setPlaying(false);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing, seek, episodeIndex]);

  useEffect(() => {
    const timer = window.setInterval(() => setProgress(id, progressRef.current), 1000);
    return () => {
      window.clearInterval(timer);
      setProgress(id, progressRef.current);
    };
  }, [id, setProgress]);

  useEffect(() => {
    if (!playing) {
      setChrome(true);
      return;
    }
    const timer = window.setTimeout(() => setChrome(false), 2600);
    return () => window.clearTimeout(timer);
  }, [playing, chrome, seek]);

  if (!title) {
    return (
      <main className="grid min-h-screen place-items-center bg-bg-deep px-6 text-center">
        <div>
          <p className="text-lg font-semibold">Judul ini tidak ada di rak.</p>
          <Link to="/" className="mt-4 inline-flex h-11 items-center text-primary">
            Kembali ke ADFLIX
          </Link>
        </div>
      </main>
    );
  }

  const episodes = title.episodes ?? [];
  const currentEpisode = episodes.find((item) => item.n === episodeIndex) ?? episodes[0];
  const nextEpisode = episodes.find((item) => item.n === (currentEpisode?.n ?? 0) + 1);

  const jump = (value: number) => {
    const next = Math.min(1, Math.max(0, value));
    progressRef.current = next;
    setLocal(next);
    setSeek((count) => count + 1);
    setPlaying(true);
    setChrome(true);
  };

  const fullscreen = () => {
    const node = shell.current;
    if (!node) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void node.requestFullscreen().catch(() => undefined);
  };

  return (
    <div ref={shell} className="relative min-h-screen overflow-hidden bg-bg-deep text-fg">
      <img
        src={title.poster}
        alt=""
        className={`absolute inset-0 h-full w-full object-cover ${playing ? "hero-drift" : ""}`}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-bg-deep via-bg-deep/25 to-bg-deep/50" />

      <div
        className={`absolute inset-0 flex flex-col transition-opacity duration-300 ${
          chrome ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="flex items-center gap-3 px-3 py-3 sm:px-6">
          <Link
            to="/"
            className="grid size-11 place-items-center rounded-full bg-bg/70 ring-1 ring-line"
            aria-label="Kembali"
          >
            <ArrowLeft className="size-5" />
          </Link>
          <div className="min-w-0">
            <Logo className="text-2xl" />
            <p className="truncate text-sm text-fg sm:text-base">
              {title.name}
              {currentEpisode ? ` · E${currentEpisode.n} ${currentEpisode.title}` : ""}
            </p>
          </div>
        </div>

        <button
          type="button"
          className="grid flex-1 place-items-center"
          onClick={() => {
            setPlaying((value) => !value);
            setChrome(true);
          }}
          aria-label={playing ? "Jeda" : "Putar"}
        >
          {playing ? null : (
            <span className="grid size-20 place-items-center rounded-full bg-play text-play-fg shadow-xl">
              <Play className="size-8 fill-current" />
            </span>
          )}
        </button>

        <div className="px-4 pb-5 sm:px-8 sm:pb-8">
          <div className="mb-3 flex items-center justify-between gap-3 text-xs text-muted sm:text-sm">
            <span className="rounded-card bg-bg/70 px-2 py-1 font-semibold tracking-wide text-fg uppercase">
              Pratinjau
            </span>
            <span className="tabular-nums">{clock(local)}</span>
          </div>
          <div
            className="group relative h-6 cursor-pointer"
            onClick={(event) => {
              const rect = event.currentTarget.getBoundingClientRect();
              jump((event.clientX - rect.left) / rect.width);
            }}
            role="slider"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(local * 100)}
            aria-label="Garis waktu pratinjau"
            tabIndex={0}
            onKeyDown={(event) => {
              if (event.key === "ArrowRight") jump(local + 10 / PREVIEW_SECONDS);
              if (event.key === "ArrowLeft") jump(local - 10 / PREVIEW_SECONDS);
            }}
          >
            <div className="absolute top-1/2 right-0 left-0 h-1 -translate-y-1/2 rounded-pill bg-line">
              <div
                className="h-full rounded-pill bg-primary"
                style={{ width: `${Math.round(local * 100)}%` }}
              />
            </div>
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setPlaying((value) => !value)}
              className="grid size-11 place-items-center rounded-full bg-play text-play-fg"
              aria-label={playing ? "Jeda" : "Putar"}
            >
              {playing ? <Pause className="size-5 fill-current" /> : <Play className="size-5 fill-current" />}
            </button>
            <button
              type="button"
              onClick={() => jump(0)}
              className="grid size-11 place-items-center rounded-full bg-bg/70 ring-1 ring-line"
              aria-label="Dari awal"
            >
              <RotateCcw className="size-4" />
            </button>
            {local < 0.18 ? (
              <button
                type="button"
                onClick={() => jump(0.18)}
                className="h-11 rounded-md bg-bg/70 px-4 text-sm font-semibold ring-1 ring-line"
              >
                Lewati intro
              </button>
            ) : null}
            {nextEpisode && local > 0.72 ? (
              <button
                type="button"
                onClick={() => {
                  setEpisodeIndex(nextEpisode.n);
                  jump(0);
                }}
                className="inline-flex h-11 items-center gap-2 rounded-md bg-play px-4 text-sm font-bold text-play-fg"
              >
                <SkipForward className="size-4" />
                Episode berikutnya
              </button>
            ) : null}
            <span className="ml-auto inline-flex items-center gap-2 text-xs text-muted">
              <VolumeX className="size-4" />
              Tanpa suara
            </span>
            <button
              type="button"
              onClick={fullscreen}
              className="grid size-11 place-items-center rounded-full bg-bg/70 ring-1 ring-line"
              aria-label="Layar penuh"
            >
              <Maximize className="size-4" />
            </button>
          </div>
          {episodes.length > 0 ? (
            <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto">
              {episodes.map((item) => (
                <button
                  key={item.n}
                  type="button"
                  onClick={() => {
                    setEpisodeIndex(item.n);
                    jump(0);
                  }}
                  className={`h-11 shrink-0 rounded-md px-3 text-sm ${
                    item.n === (currentEpisode?.n ?? item.n)
                      ? "bg-fg font-semibold text-play-fg"
                      : "bg-bg/70 text-fg ring-1 ring-line"
                  }`}
                >
                  E{item.n} {item.title}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      </div>

      {!chrome ? (
        <button
          type="button"
          className="absolute inset-0"
          aria-label="Tampilkan kontrol"
          onClick={() => setChrome(true)}
        />
      ) : null}
    </div>
  );
}
