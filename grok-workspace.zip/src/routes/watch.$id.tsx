import { createFileRoute } from "@tanstack/react-router";
import { Player } from "@/components/adflix/player";
import { getTitle } from "@/data/catalog";

type WatchSearch = { ep: number };

export const Route = createFileRoute("/watch/$id")({
  validateSearch: (search: Record<string, unknown>): WatchSearch => {
    const value = Number(search.ep);
    return { ep: Number.isFinite(value) && value > 0 ? Math.floor(value) : 1 };
  },
  head: ({ params }) => ({
    meta: [{ title: `${getTitle(params.id)?.name ?? "Putar"} · ADFLIX` }],
  }),
  component: WatchPage,
});

function WatchPage() {
  const { id } = Route.useParams();
  const { ep } = Route.useSearch();
  return <Player id={id} episode={ep} />;
}
