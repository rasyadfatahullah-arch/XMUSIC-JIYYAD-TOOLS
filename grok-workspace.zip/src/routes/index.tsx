import { createFileRoute } from "@tanstack/react-router";
import { Browse } from "@/components/adflix/browse";
import { Profiles } from "@/components/adflix/profiles";
import { useWatch } from "@/lib/watch-store";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const profileId = useWatch((state) => state.profileId);
  const setProfile = useWatch((state) => state.setProfile);
  if (!profileId) return <Profiles onPick={setProfile} />;
  return <Browse profileId={profileId} />;
}
