export type Kind = "series" | "film";

export type Episode = {
  n: number;
  title: string;
  blurb: string;
  minutes: number;
};

export type TitleItem = {
  id: string;
  name: string;
  kind: Kind;
  year: number;
  rating: "SU" | "13+" | "17+";
  match: number;
  genres: string[];
  minutes: number;
  seasons?: number;
  tagline: string;
  synopsis: string;
  cast: string[];
  poster: string;
  original: boolean;
  featured?: boolean;
  episodes?: Episode[];
};

const ep = (
  n: number,
  title: string,
  blurb: string,
  minutes = 48,
): Episode => ({ n, title, blurb, minutes });

export const TITLES: TitleItem[] = [
  {
    id: "midnight-harbor",
    name: "Midnight Harbor",
    kind: "series",
    year: 2025,
    rating: "17+",
    match: 98,
    genres: ["Kejahatan", "Thriller"],
    minutes: 52,
    seasons: 2,
    tagline: "Dermaga tidak pernah benar-benar sepi.",
    synopsis:
      "Di pelabuhan yang tak pernah kering, detektif Laila Rahman memburu jaringan yang memakai identitas orang mati. Setiap saksi lebih memilih ombak daripada pengakuan.",
    cast: ["Laila Rahman", "Arka Wijaya", "Siena Vogel", "Bima Latif"],
    poster: "/media/midnight-harbor.jpg",
    original: true,
    featured: true,
    episodes: [
      ep(1, "Orang yang tidak pulang", "Sebuah koper tanpa pemilik mengapung di dermaga tiga. Isinya bukan barang — daftar nama."),
      ep(2, "Lampu merah di air", "Laila mengikuti kapal umpan dan menemukan awak yang sudah dinyatakan tenggelam tahun lalu."),
      ep(3, "Saksi garam", "Seorang juru masak kapal mau bicara, asal keluarganya dipindahkan sebelum fajar."),
    ],
  },
  {
    id: "glass-throne",
    name: "The Glass Throne",
    kind: "series",
    year: 2024,
    rating: "13+",
    match: 96,
    genres: ["Fantasi", "Drama"],
    minutes: 54,
    seasons: 1,
    tagline: "Takhta yang retak tetap menggigit.",
    synopsis:
      "Pewaris yang diusir kembali ke istana kaca. Pecahan takhta itu memilih raja — dan ia mulai memilih orang yang harus dilupakan.",
    cast: ["Amara Voss", "Kenan Putra", "Ilyas Dorn", "Raka Senja"],
    poster: "/media/glass-throne.jpg",
    original: true,
    featured: true,
    episodes: [
      ep(1, "Pecahan pertama", "Amara melangkah ke aula yang mengingat wajahnya, meski kerajaan menghapus namanya."),
      ep(2, "Sumpah yang retak", "Sebuah shard menunjukkan masa depan yang hanya terjadi jika ia berkhianat."),
      ep(3, "Ruang tanpa bayangan", "Penasihat lama menawarkan mahkota — dengan harga sebuah kota di perbatasan."),
    ],
  },
  {
    id: "neon-district",
    name: "Neon District",
    kind: "film",
    year: 2026,
    rating: "17+",
    match: 94,
    genres: ["Fiksi Ilmiah", "Aksi"],
    minutes: 124,
    tagline: "Satu chip. Satu kota. Nol siang.",
    synopsis:
      "Kurir malam di kota tanpa matahari harus mengantar chip yang bisa mematikan seluruh jaringan — atau menjualnya kepada orang yang sudah mematikannya sekali.",
    cast: ["Ryo Mahendra", "Nadya Chen", "Omar Vale"],
    poster: "/media/neon-district.jpg",
    original: true,
    featured: true,
  },
  {
    id: "salt-ember",
    name: "Salt & Ember",
    kind: "film",
    year: 2025,
    rating: "13+",
    match: 91,
    genres: ["Drama", "Romansa"],
    minutes: 108,
    tagline: "Resep keluarga terbakar lebih dulu.",
    synopsis:
      "Dua koki yang berseteru membuka dapur musiman di bibir gunung berapi. Menu pembuka mereka adalah rahasia yang tidak boleh disajikan bersama.",
    cast: ["Sari Lembayung", "Eliot Marsh", "Omah Tala"],
    poster: "/media/salt-ember.jpg",
    original: false,
  },
  {
    id: "orbit-nine",
    name: "Orbit Nine",
    kind: "series",
    year: 2026,
    rating: "13+",
    match: 97,
    genres: ["Fiksi Ilmiah", "Misteri"],
    minutes: 49,
    seasons: 1,
    tagline: "Stasiun ini belajar mengingat.",
    synopsis:
      "Cincin Orbit Sembilan kehilangan suara dari Bumi. Awak terakhir menyadari stasiun itu tidak kosong — ia sedang menyusun kalimat pertamanya.",
    cast: ["Dr. Hana Yusuf", "Cole Ibarra", "Mikael Strom", "Yen Prado"],
    poster: "/media/orbit-nine.jpg",
    original: true,
    featured: true,
    episodes: [
      ep(1, "Sinyal yang menjawab", "Panggilan darurat kembali tiga detik sebelum dikirim."),
      ep(2, "Kamar kosong", "Sebuah ranjang yang tidak terdaftar mulai menghangat setiap siklus malam."),
      ep(3, "Tata bahasa bintang", "Hana menerjemahkan getaran lambung kapal menjadi sebuah peringatan."),
    ],
  },
  {
    id: "last-harvest",
    name: "Last Harvest",
    kind: "film",
    year: 2024,
    rating: "17+",
    match: 89,
    genres: ["Horor", "Thriller"],
    minutes: 96,
    tagline: "Ladang itu menolak kalender.",
    synopsis:
      "Seorang agronom diundang ke desa panen yang tidak mengakui musim. Malam pertama, lentera merah menyala di barisan yang seharusnya tandus.",
    cast: ["Dinda Siregar", "Pak Holan", "Wira Embun"],
    poster: "/media/last-harvest.jpg",
    original: false,
  },
  {
    id: "velvet-alibi",
    name: "Velvet Alibi",
    kind: "series",
    year: 2025,
    rating: "17+",
    match: 93,
    genres: ["Aksi", "Kejahatan"],
    minutes: 46,
    seasons: 1,
    tagline: "Satu rencana. Empat versi.",
    synopsis:
      "Empat pencuri kelas atas menyiapkan satu malam di museum. Masalahnya, salah satu dari mereka sudah menjual denah itu — dua kali.",
    cast: ["Vera Quinn", "Jovan Hale", "Tari Moss", "Noel Ardi"],
    poster: "/media/velvet-alibi.jpg",
    original: true,
    episodes: [
      ep(1, "Undangan tertutup", "Gala pembuka menjadi latihan. Vera menghitung penjaga, lalu kehilangan hitungannya."),
      ep(2, "Kaca yang jujur", "Sebuah vitrin menyimpan lebih dari permata: rekaman suara rencana mereka."),
      ep(3, "Pembeli kedua", "Noel bertemu orang yang membayar alibi sebelum kejahatan terjadi."),
    ],
  },
  {
    id: "kings-of-rain",
    name: "Kings of Rain",
    kind: "film",
    year: 2023,
    rating: "13+",
    match: 88,
    genres: ["Olahraga", "Drama"],
    minutes: 118,
    tagline: "Final sebelum stadion dirobohkan.",
    synopsis:
      "Kapten tim kota hujan harus memenangkan piala terakhir di kandang yang akan digusur. Striker andalannya menyembunyikan cedera yang tidak boleh dilihat kamera.",
    cast: ["Dimas Utara", "Coach Lestari", "Farah Quinn"],
    poster: "/media/kings-of-rain.jpg",
    original: false,
  },
  {
    id: "paper-wolves",
    name: "Paper Wolves",
    kind: "series",
    year: 2025,
    rating: "17+",
    match: 95,
    genres: ["Thriller", "Drama"],
    minutes: 50,
    seasons: 1,
    tagline: "Berkas yang tidak boleh ada.",
    synopsis:
      "Arsiparis negara menemukan map tanpa nomor. Membocorkannya berarti menghilang. Menyimpannya berarti ikut menandatangani dusta.",
    cast: ["Intan Bharata", "Hugo Salem", "Maya Kertanegara"],
    poster: "/media/paper-wolves.jpg",
    original: true,
    episodes: [
      ep(1, "Map tanpa nomor", "Intan membuka laci yang tidak ada di denah gedung."),
      ep(2, "Tinta basah", "Sebuah tanda tangan di berkas itu masih belum kering — dari rapat yang berlangsung sekarang."),
      ep(3, "Serigala kertas", "Hugo menawarkan perlindungan, lalu menanyakan isi map yang belum Intan sebutkan."),
    ],
  },
  {
    id: "little-comets",
    name: "Little Comets",
    kind: "series",
    year: 2026,
    rating: "SU",
    match: 92,
    genres: ["Keluarga", "Petualangan"],
    minutes: 28,
    seasons: 1,
    tagline: "Pesan dari tahun yang belum terjadi.",
    synopsis:
      "Dua saudara menemukan komet mungil di atap rumah. Setiap cahaya yang jatuh adalah pesan singkat dari hari yang masih jauh — dan satu di antaranya minta mereka tidak membuka pintu besok.",
    cast: ["Ayu", "Reza", "Bibi Nuri", "Pak Pos Danu"],
    poster: "/media/little-comets.jpg",
    original: true,
    episodes: [
      ep(1, "Atap yang bersinar", "Komet pertama mendarat di jemuran dan menulis nama Ayu dengan debu hangat.", 26),
      ep(2, "Surat untuk besok", "Reza membaca peringatan tentang pintu biru. Rumah mereka tidak punya pintu biru.", 27),
      ep(3, "Peta langit kecil", "Bibi Nuri mengaku pernah menerima komet yang sama waktu seusia mereka.", 28),
    ],
  },
];

export function getTitle(id: string) {
  return TITLES.find((title) => title.id === id);
}

export function forViewer(kids: boolean) {
  if (!kids) return TITLES;
  return TITLES.filter(
    (title) => title.rating !== "17+" && !title.genres.includes("Horor"),
  );
}

export function similarTo(title: TitleItem, pool: TitleItem[]) {
  const related = pool.filter(
    (item) => item.id !== title.id && item.genres.some((genre) => title.genres.includes(genre)),
  );
  if (related.length >= 4) return related.slice(0, 8);
  const rest = pool.filter(
    (item) => item.id !== title.id && !related.some((hit) => hit.id === item.id),
  );
  return [...related, ...rest].slice(0, 8);
}
