//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dp4ElI1f.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/watch/$id"],
		preloads: [
			"/assets/index-mfYwXDIs.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/catalog-Bf9T-kYy.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mfYwXDIs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B9Dj-gD7.js", "/assets/logo-Dkej2Smo.js"]
	},
	"/watch/$id": {
		filePath: "/workspace/src/routes/watch.$id.tsx",
		children: void 0,
		preloads: ["/assets/watch._id-Clh5G5L1.js", "/assets/logo-Dkej2Smo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
