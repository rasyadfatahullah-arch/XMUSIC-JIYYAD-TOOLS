import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/logo-CndfEplW.js
var import_jsx_runtime = require_jsx_runtime();
var PROFILES = [
	{
		id: "jiyyad",
		name: "Jiyyad",
		tone: "primary",
		note: "Semua judul"
	},
	{
		id: "keluarga",
		name: "Keluarga",
		tone: "ink",
		note: "Bersama di sofa"
	},
	{
		id: "anak",
		name: "Anak",
		tone: "soft",
		note: "Tanpa 17+ & horor"
	}
];
var useWatch = create()(persist((set) => ({
	profileId: null,
	myList: [],
	progress: {},
	setProfile: (profileId) => set({ profileId }),
	toggleList: (id) => set((state) => ({ myList: state.myList.includes(id) ? state.myList.filter((item) => item !== id) : [id, ...state.myList] })),
	setProgress: (id, value) => set((state) => ({ progress: {
		...state.progress,
		[id]: Math.min(1, Math.max(0, value))
	} }))
}), {
	name: "adflix-watch",
	merge: (persistedState, currentState) => {
		const persisted = persistedState ?? {};
		return {
			...currentState,
			...persisted,
			profileId: currentState.profileId ?? persisted.profileId ?? null,
			myList: currentState.myList.length ? currentState.myList : persisted.myList ?? [],
			progress: {
				...persisted.progress ?? {},
				...currentState.progress
			}
		};
	}
}));
function Logo({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `font-display tracking-widest text-primary leading-none ${className}`,
		children: "ADFLIX"
	});
}
//#endregion
export { PROFILES as n, useWatch as r, Logo as t };
