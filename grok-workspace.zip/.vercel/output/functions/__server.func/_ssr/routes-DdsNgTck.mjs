import { i as __toESM } from "../_runtime.mjs";
import { r as similarTo, t as forViewer } from "./catalog-BBReXIEW.mjs";
import { J as require_react, S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, c as Play, d as Info, f as ChevronRight, g as Bell, h as Check, m as ChevronDown, p as ChevronLeft, s as Plus, t as X } from "../_libs/lucide-react.mjs";
import { n as PROFILES, r as useWatch, t as Logo } from "./logo-CndfEplW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DdsNgTck.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		id: "home",
		label: "Beranda"
	},
	{
		id: "series",
		label: "Serial"
	},
	{
		id: "films",
		label: "Film"
	},
	{
		id: "new",
		label: "Baru & Populer"
	},
	{
		id: "list",
		label: "Daftar Saya"
	}
];
function Header({ section, onSection, onSearch, onSwitchProfile, profileId, fresh, onOpen }) {
	const [solid, setSolid] = (0, import_react.useState)(false);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const profile = PROFILES.find((item) => item.id === profileId) ?? PROFILES[0];
	(0, import_react.useEffect)(() => {
		const onScroll = () => setSolid(window.scrollY > 16);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const tone = profile.tone === "primary" ? "bg-primary text-fg" : profile.tone === "soft" ? "bg-fg text-play-fg" : "bg-surface-2 text-fg";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-40 transition-colors duration-300 ${solid ? "bg-bg/95 backdrop-blur-md" : "bg-gradient-to-b from-bg via-bg/70 to-transparent"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-4 px-4 py-3 sm:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onSection("home"),
					"aria-label": "ADFLIX beranda",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "text-3xl sm:text-4xl" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-4 md:flex",
					"aria-label": "Utama",
					children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onSection(link.id),
						className: `text-sm transition ${section === link.id ? "font-semibold text-fg" : "text-muted hover:text-fg"}`,
						children: link.label
					}, link.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-1 sm:gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onSearch,
							className: "grid size-11 place-items-center rounded-full text-fg hover:bg-surface",
							"aria-label": "Cari",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMenu((open) => open === "bell" ? null : "bell"),
								className: "grid size-11 place-items-center rounded-full text-fg hover:bg-surface",
								"aria-label": "Baru masuk",
								"aria-expanded": menu === "bell",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
							}), menu === "bell" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-0 mt-2 w-72 overflow-hidden rounded-card border border-line bg-surface shadow-2xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "border-b border-line px-4 py-3 text-xs font-semibold tracking-wide text-muted uppercase",
									children: "Baru di ADFLIX"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: fresh.map((title) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setMenu(null);
										onOpen(title.id);
									},
									className: "flex w-full items-center gap-3 px-3 py-2 text-left hover:bg-surface-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: title.poster,
										alt: "",
										className: "h-14 w-10 rounded-card object-cover"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-semibold",
										children: title.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-muted",
										children: [
											title.year,
											" · ",
											title.kind === "series" ? "Serial" : "Film"
										]
									})] })]
								}) }, title.id)) })]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setMenu((open) => open === "profile" ? null : "profile"),
								className: "flex items-center gap-1 rounded-full py-1 pr-1 pl-1 hover:bg-surface",
								"aria-label": "Profil",
								"aria-expanded": menu === "profile",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid size-8 place-items-center rounded-card font-display text-lg ${tone}`,
									children: profile.name.slice(0, 1)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "hidden size-4 text-fg sm:block" })]
							}), menu === "profile" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-0 mt-2 w-56 overflow-hidden rounded-card border border-line bg-surface shadow-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-4 pt-3 text-sm font-semibold",
										children: profile.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-4 pb-3 text-xs text-muted",
										children: "jiyyad tools"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											setMenu(null);
											onSwitchProfile();
										},
										className: "w-full border-t border-line px-4 py-3 text-left text-sm hover:bg-surface-2",
										children: "Ganti profil"
									})
								]
							}) : null]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "no-scrollbar flex gap-4 overflow-x-auto px-4 pb-3 md:hidden",
			"aria-label": "Utama",
			children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onSection(link.id),
				className: `shrink-0 text-sm ${section === link.id ? "font-semibold text-fg" : "text-muted"}`,
				children: link.label
			}, link.id))
		})]
	});
}
function Hero({ titles, index, onIndex, inList, onPlay, onInfo, onToggleList }) {
	const title = titles[index] ?? titles[0];
	if (!title) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-[100svh] overflow-hidden sm:h-[92svh]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: title.poster,
				alt: "",
				className: "hero-drift absolute inset-0 h-full w-full object-cover object-[center_18%]"
			}, title.id),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-r from-bg via-bg/80 to-bg/15" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-bg via-bg/20 to-bg/40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 max-w-3xl px-4 pt-28 pb-8 sm:px-10 sm:pb-14 lg:px-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold tracking-widest text-fg/80 uppercase",
						children: [
							title.original ? "Hanya di ADFLIX" : "Pilihan ADFLIX",
							" ·",
							" ",
							title.kind === "series" ? "Serial" : "Film"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 max-w-xl text-balance font-display text-5xl leading-none tracking-wide text-fg sm:text-7xl lg:text-8xl",
						children: title.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg font-medium text-fg sm:text-xl",
						children: title.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-fg tabular-nums",
								children: [title.match, "% cocok"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title.year }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-card border border-line px-1.5 py-0.5 text-xs text-fg",
								children: title.rating
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title.kind === "series" ? `${title.seasons} musim` : `${Math.floor(title.minutes / 60)}j ${title.minutes % 60}m` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-card border border-line px-1.5 py-0.5 text-xs text-fg",
								children: "HD"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 line-clamp-2 max-w-xl text-pretty text-sm text-fg/90 sm:line-clamp-3 sm:text-base",
						children: title.synopsis
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onPlay(title.id),
								className: "inline-flex h-12 items-center gap-2 rounded-md bg-play px-6 text-base font-bold text-play-fg transition hover:bg-play/85",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current" }), "Putar"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onInfo(title.id),
								className: "inline-flex h-12 items-center gap-2 rounded-md bg-surface-2/80 px-5 text-base font-semibold text-fg ring-1 ring-line backdrop-blur-sm transition hover:bg-surface-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" }), "Info lainnya"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onToggleList(title.id),
								className: "grid size-12 place-items-center rounded-full border border-line bg-bg/50 text-fg backdrop-blur-sm hover:border-fg",
								"aria-label": inList ? "Hapus dari Daftar Saya" : "Tambah ke Daftar Saya",
								children: inList ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
							})
						]
					}),
					titles.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex gap-2",
						role: "tablist",
						"aria-label": "Judul unggulan",
						children: titles.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": itemIndex === index,
							"aria-label": item.name,
							onClick: () => onIndex(itemIndex),
							className: `h-1.5 rounded-pill transition-all ${itemIndex === index ? "w-8 bg-fg" : "w-4 bg-fg/35 hover:bg-fg/60"}`
						}, item.id))
					}) : null
				]
			})
		]
	});
}
function TitleCard({ title, rank, progress, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-full items-end",
		children: [rank ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rank-num -mr-2 mb-1 shrink-0 select-none",
			children: rank
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(title.id),
			className: "group relative aspect-[2/3] w-full min-w-0 overflow-hidden rounded-card bg-surface text-left shadow-lg ring-1 ring-transparent transition duration-200 hover:-translate-y-1 hover:ring-fg/70",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: title.poster,
					alt: title.name,
					className: "h-full w-full object-cover transition duration-300 group-hover:scale-105"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg-deep via-bg-deep/80 to-transparent px-2 pt-12 pb-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "line-clamp-2 block text-xs font-semibold text-fg sm:text-sm",
						children: title.name
					})
				}),
				typeof progress === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-x-0 bottom-0 h-1 bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block h-full bg-primary",
						style: { width: `${Math.round(progress * 100)}%` }
					})
				}) : null
			]
		})]
	});
}
function Row({ title, items, onOpen, ranked = false, progressOf }) {
	const scroller = (0, import_react.useRef)(null);
	if (items.length === 0) return null;
	const move = (direction) => {
		const node = scroller.current;
		if (!node) return;
		node.scrollBy({
			left: direction * node.clientWidth * .75,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative mt-2 mb-6 sm:mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-2 flex items-end justify-between px-4 sm:px-10 lg:px-14",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold text-fg sm:text-xl",
				children: title
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "group/row relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Geser kiri",
					onClick: () => move(-1),
					className: "absolute top-1/2 left-2 z-10 hidden size-11 -translate-y-1/2 place-items-center rounded-full bg-bg/80 text-fg ring-1 ring-line sm:grid sm:opacity-0 sm:transition sm:group-hover/row:opacity-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: scroller,
					className: "no-scrollbar flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 py-3 sm:px-10 sm:py-4 lg:px-14",
					children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: ranked ? "w-52 shrink-0 snap-start sm:w-64" : "w-32 shrink-0 snap-start sm:w-44",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, {
							title: item,
							rank: ranked ? index + 1 : void 0,
							progress: progressOf?.(item.id),
							onOpen
						})
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Geser kanan",
					onClick: () => move(1),
					className: "absolute top-1/2 right-2 z-10 hidden size-11 -translate-y-1/2 place-items-center rounded-full bg-bg/80 text-fg ring-1 ring-line sm:grid sm:opacity-0 sm:transition sm:group-hover/row:opacity-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-6" })
				})
			]
		})]
	});
}
function PosterGrid({ items, onOpen, progressOf, empty }) {
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-4 rounded-card border border-line bg-surface px-6 py-16 text-center sm:mx-10 lg:mx-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-semibold",
			children: empty ?? "Belum ada judul di sini."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Jelajahi beranda, atau ganti profil bila katalognya disaring."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 sm:px-10 md:grid-cols-4 lg:grid-cols-5 lg:px-14",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, {
			title: item,
			onOpen,
			progress: progressOf?.(item.id)
		}, item.id))
	});
}
function metaLine(title) {
	if (title.kind === "series") return `${title.seasons} musim · ${title.minutes} mnt/episode`;
	return `${Math.floor(title.minutes / 60)}j ${title.minutes % 60}m`;
}
function Detail({ title, pool, inList, onClose, onOpen, onToggleList }) {
	const related = similarTo(title, pool);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 overflow-y-auto bg-bg-deep/80",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": title.name,
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto min-h-screen w-full max-w-4xl bg-surface sm:my-8 sm:min-h-0 sm:overflow-hidden sm:rounded-card",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-80 sm:h-[28rem]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: title.poster,
							alt: "",
							className: "h-full w-full object-cover object-[center_20%]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-surface via-surface/20 to-bg-deep/30" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClose,
							className: "absolute top-4 right-4 grid size-11 place-items-center rounded-full bg-bg/80 text-fg ring-1 ring-line",
							"aria-label": "Tutup",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 bottom-0 px-5 pb-5 sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-widest text-fg/80 uppercase",
									children: title.original ? "ADFLIX Original" : "Koleksi ADFLIX"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-5xl leading-none tracking-wide sm:text-7xl",
									children: title.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/watch/$id",
										params: { id: title.id },
										search: { ep: 1 },
										className: "inline-flex h-12 items-center gap-2 rounded-md bg-play px-5 text-base font-bold text-play-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current" }), "Putar"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onToggleList(title.id),
										className: "inline-flex h-12 items-center gap-2 rounded-md bg-surface-2 px-4 text-sm font-semibold ring-1 ring-line",
										children: [inList ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), inList ? "Di Daftar Saya" : "Daftar Saya"]
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 px-5 py-6 sm:grid-cols-[1.4fr_0.8fr] sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-fg tabular-nums",
								children: [title.match, "% cocok"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title.year }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-card border border-line px-1.5 text-xs text-fg",
								children: title.rating
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: metaLine(title) })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-pretty text-sm leading-relaxed text-fg sm:text-base",
						children: title.synopsis
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-faint",
								children: "Pemain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: title.cast.join(", ")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-faint",
								children: "Genre"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: title.genres.join(" · ")
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-faint",
								children: "Tayang"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-fg",
								children: "ADFLIX · jiyyad tools"
							})] })
						]
					})]
				}),
				title.episodes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 pb-6 sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-3 text-lg font-semibold",
						children: "Episode"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "divide-y divide-line border-y border-line",
						children: title.episodes.map((episode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$id",
							params: { id: title.id },
							search: { ep: episode.n },
							className: "flex items-start gap-4 py-4 hover:bg-surface-2/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-6 pt-1 text-xl font-semibold text-muted tabular-nums",
									children: episode.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: episode.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "shrink-0 text-xs text-muted tabular-nums",
											children: [episode.minutes, " mnt"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-sm text-pretty text-muted",
										children: episode.blurb
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "mt-1 size-4 shrink-0 fill-current" })
							]
						}) }, episode.n))
					})]
				}) : null,
				related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 pb-8 sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-3 text-lg font-semibold",
						children: "Lebih seperti ini"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: related.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, {
							title: item,
							onOpen
						}, item.id))
					})]
				}) : null
			]
		})
	});
}
var NOTES = [
	{
		label: "Tentang ADFLIX",
		body: "ADFLIX adalah layanan tontonan orisinal milik jiyyad tools. Semua judul, tokoh, dan gambar di katalog ini fiksi — dibuat untuk ditonton di peramban, bukan salinan karya pihak lain."
	},
	{
		label: "Profil",
		body: "Profil Jiyyad, Keluarga, dan Anak tersimpan di perangkat ini. Profil Anak menyembunyikan judul 17+ dan horor. Tidak ada akun yang perlu dibuat."
	},
	{
		label: "Audio & subtitle",
		body: "Antarmuka berbahasa Indonesia. Pratinjau pemutar bersifat sinematik dan tanpa suara — garis waktu, intro, dan episode tetap bisa dijelajahi."
	},
	{
		label: "Bantuan",
		body: "Cari dengan ikon kaca pembesar atau tombol garis miring. Tambahkan judul ke Daftar Saya, lalu lanjutkan dari baris Lanjutkan menonton setelah kamu menekan Putar."
	}
];
function Footer() {
	const [open, setOpen] = (0, import_react.useState)(null);
	const note = NOTES.find((item) => item.label === open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-10 border-t border-line px-4 py-10 text-sm text-faint sm:px-10 lg:px-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base text-muted",
				children: "Ada pertanyaan? Ini meja jiyyad tools."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: NOTES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen(item.label),
					className: "text-left text-muted underline-offset-4 hover:text-fg hover:underline",
					children: item.label
				}) }, item.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-xs",
				children: "© 2026 jiyyad tools. ADFLIX."
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 grid place-items-end bg-bg-deep/70 sm:place-items-center",
				onClick: () => setOpen(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-t-card bg-surface p-6 sm:rounded-card",
					onClick: (event) => event.stopPropagation(),
					role: "dialog",
					"aria-label": note.label,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold text-fg",
							children: note.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-pretty text-sm leading-relaxed text-muted",
							children: note.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setOpen(null),
							className: "mt-5 h-11 rounded-md bg-play px-5 text-sm font-bold text-play-fg",
							children: "Tutup"
						})
					]
				})
			}) : null
		]
	});
}
function hasGenre(title, genres) {
	return title.genres.some((genre) => genres.includes(genre));
}
function Browse({ profileId }) {
	const navigate = useNavigate();
	const kids = profileId === "anak";
	const pool = (0, import_react.useMemo)(() => forViewer(kids), [kids]);
	const myList = useWatch((state) => state.myList);
	const progress = useWatch((state) => state.progress);
	const toggleList = useWatch((state) => state.toggleList);
	const setProfile = useWatch((state) => state.setProfile);
	const [section, setSection] = (0, import_react.useState)("home");
	const [feature, setFeature] = (0, import_react.useState)(0);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [toast, setToast] = (0, import_react.useState)(null);
	const featured = pool.filter((title) => title.featured);
	const spotlight = featured.length > 0 ? featured : pool.slice(0, 1);
	const safeFeature = spotlight.length ? feature % spotlight.length : 0;
	const active = pool.find((title) => title.id === activeId) ?? null;
	(0, import_react.useEffect)(() => {
		if (section !== "home" || searchOpen || active) return;
		const timer = window.setInterval(() => {
			setFeature((current) => current + 1);
		}, 8e3);
		return () => window.clearInterval(timer);
	}, [
		section,
		searchOpen,
		active,
		spotlight.length
	]);
	(0, import_react.useEffect)(() => {
		const previous = document.body.style.overflow;
		document.body.style.overflow = active || searchOpen ? "hidden" : previous;
		return () => {
			document.body.style.overflow = previous;
		};
	}, [active, searchOpen]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const tag = event.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") {
				if (event.key === "Escape") setSearchOpen(false);
				return;
			}
			if (event.key === "/") {
				event.preventDefault();
				setSearchOpen(true);
			}
			if (event.key === "Escape") {
				setActiveId(null);
				setSearchOpen(false);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const play = (id) => {
		navigate({
			to: "/watch/$id",
			params: { id },
			search: { ep: 1 }
		});
	};
	const onToggle = (id) => {
		const had = useWatch.getState().myList.includes(id);
		toggleList(id);
		setToast(had ? "Dihapus dari Daftar Saya" : "Masuk ke Daftar Saya");
		window.setTimeout(() => setToast(null), 1600);
	};
	const saved = myList.map((id) => pool.find((title) => title.id === id)).filter((title) => Boolean(title));
	const continueWatching = pool.filter((title) => {
		const value = progress[title.id] ?? 0;
		return value > .02 && value < .98;
	});
	const trending = [...pool].sort((a, b) => b.match - a.match);
	const thrill = pool.filter((title) => hasGenre(title, [
		"Kejahatan",
		"Thriller",
		"Horor",
		"Aksi"
	]));
	const beyond = pool.filter((title) => hasGenre(title, [
		"Fiksi Ilmiah",
		"Fantasi",
		"Misteri"
	]));
	const easy = pool.filter((title) => hasGenre(title, [
		"Keluarga",
		"Olahraga",
		"Drama",
		"Romansa"
	]));
	const originals = pool.filter((title) => title.original);
	const fresh = [...pool].sort((a, b) => b.year - a.year || b.match - a.match);
	const results = pool.filter((title) => {
		return [
			title.name,
			title.tagline,
			title.synopsis,
			...title.genres,
			...title.cast
		].join(" ").toLowerCase().includes(query.trim().toLowerCase());
	});
	const progressOf = (id) => {
		const value = progress[id];
		return value && value > .02 ? value : void 0;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
				section,
				onSection: (next) => {
					setSection(next);
					setSearchOpen(false);
					window.scrollTo({
						top: 0,
						behavior: "smooth"
					});
				},
				onSearch: () => setSearchOpen(true),
				onSwitchProfile: () => setProfile(null),
				profileId,
				fresh: fresh.slice(0, 4),
				onOpen: setActiveId
			}),
			section === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {
					titles: spotlight,
					index: safeFeature,
					onIndex: setFeature,
					inList: spotlight[safeFeature] ? myList.includes(spotlight[safeFeature].id) : false,
					onPlay: play,
					onInfo: setActiveId,
					onToggleList: onToggle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					title: "Lanjutkan menonton",
					items: continueWatching,
					onOpen: setActiveId,
					progressOf
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					title: "Sedang tren hari ini",
					items: trending,
					onOpen: setActiveId,
					ranked: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					title: "Hanya di ADFLIX",
					items: originals,
					onOpen: setActiveId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					title: "Yang bikin melek",
					items: thrill,
					onOpen: setActiveId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					title: "Di luar bumi",
					items: beyond,
					onOpen: setActiveId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					title: "Malam yang lebih tenang",
					items: easy,
					onOpen: setActiveId
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-32 pb-6 sm:px-10 sm:pt-28 lg:px-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl tracking-wide sm:text-6xl",
					children: section === "series" ? "Serial" : section === "films" ? "Film" : section === "new" ? "Baru & Populer" : "Daftar Saya"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted sm:text-base",
					children: section === "list" ? "Judul yang kamu simpan di perangkat ini." : section === "new" ? "Rilis terbaru di rak ADFLIX." : kids ? "Profil Anak hanya menampilkan judul yang lebih ringan." : "Katalog orisinal ADFLIX oleh jiyyad tools."
				})]
			}),
			section === "series" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGrid, {
				items: pool.filter((title) => title.kind === "series"),
				onOpen: setActiveId,
				progressOf
			}) : null,
			section === "films" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGrid, {
				items: pool.filter((title) => title.kind === "film"),
				onOpen: setActiveId,
				progressOf
			}) : null,
			section === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGrid, {
				items: fresh,
				onOpen: setActiveId,
				progressOf
			}) : null,
			section === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGrid, {
				items: saved,
				onOpen: setActiveId,
				progressOf,
				empty: "Daftar Saya masih kosong."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
				title: active,
				pool,
				inList: myList.includes(active.id),
				onClose: () => setActiveId(null),
				onOpen: setActiveId,
				onToggleList: onToggle
			}) : null,
			searchOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 overflow-y-auto bg-bg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-0 flex items-center gap-3 border-b border-line bg-bg px-4 py-3 sm:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5 shrink-0 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							autoFocus: true,
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Judul, genre, atau pemain",
							className: "h-12 w-full bg-transparent text-lg text-fg outline-none placeholder:text-faint",
							"aria-label": "Cari katalog"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setSearchOpen(false);
								setQuery("");
							},
							className: "grid size-11 shrink-0 place-items-center rounded-full hover:bg-surface",
							"aria-label": "Tutup pencarian",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-6",
					children: query.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGrid, {
						items: results,
						onOpen: (id) => {
							setSearchOpen(false);
							setActiveId(id);
						},
						empty: `Tidak ada hasil untuk “${query.trim()}”.`
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 sm:px-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Coba “pelabuhan”, “fantasi”, atau “Laila”."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [
								"Kejahatan",
								"Fantasi",
								"Fiksi Ilmiah",
								"Keluarga",
								"Thriller"
							].map((genre) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setQuery(genre),
								className: "h-10 rounded-pill border border-line px-4 text-sm text-fg hover:border-fg",
								children: genre
							}, genre))
						})]
					})
				})]
			}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-pill bg-fg px-4 py-2 text-sm font-semibold text-play-fg shadow-lg",
				children: toast
			}) : null
		]
	});
}
var toneClass = {
	primary: "bg-primary text-fg",
	ink: "bg-surface-2 text-fg",
	soft: "bg-fg text-play-fg"
};
function Profiles({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center bg-bg px-6 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "mb-10 text-5xl sm:text-6xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-balance text-center text-3xl font-medium text-fg sm:text-5xl",
				children: "Siapa yang menonton?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center text-sm text-muted sm:text-base",
				children: "Pilih profil. Daftar dan progres tersimpan di perangkat ini."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 grid w-full max-w-3xl grid-cols-3 gap-3 sm:gap-8",
				children: PROFILES.map((profile) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onPick(profile.id),
						className: "group flex w-full max-w-40 flex-col items-center gap-3 rounded-card focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-fg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid aspect-square w-full place-items-center rounded-card font-display text-5xl transition duration-200 group-hover:ring-2 group-hover:ring-fg sm:text-7xl ${toneClass[profile.tone]}`,
								children: profile.name.slice(0, 1)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-center text-sm text-muted transition group-hover:text-fg sm:text-lg",
								children: profile.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-center text-xs text-faint sm:block",
								children: profile.note
							})
						]
					})
				}, profile.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-14 text-center text-sm text-faint",
				children: ["ADFLIX · layanan tontonan oleh ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "jiyyad tools"
				})]
			})
		]
	});
}
function Home() {
	const profileId = useWatch((state) => state.profileId);
	const setProfile = useWatch((state) => state.setProfile);
	if (!profileId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Profiles, { onPick: setProfile });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Browse, { profileId });
}
//#endregion
export { Home as component };
