import { i as __toESM } from "../_runtime.mjs";
import { n as getTitle } from "./catalog-BBReXIEW.mjs";
import { J as require_react, S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ArrowLeft, c as Play, i as SkipForward, l as Pause, n as VolumeX, o as RotateCcw, u as Maximize } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-l9FbawMW.mjs";
import { r as useWatch, t as Logo } from "./logo-CndfEplW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watch._id-CMiJnCX6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PREVIEW_SECONDS = 84;
function clock(progress) {
	const current = Math.min(PREVIEW_SECONDS, Math.floor(progress * PREVIEW_SECONDS));
	const format = (value) => {
		const minutes = Math.floor(value / 60);
		const seconds = value % 60;
		return `${minutes}:${String(seconds).padStart(2, "0")}`;
	};
	return `${format(current)} / ${format(PREVIEW_SECONDS)}`;
}
function Player({ id, episode }) {
	const navigate = useNavigate();
	const title = getTitle(id);
	const profileId = useWatch((state) => state.profileId);
	const saved = useWatch((state) => state.progress[id] ?? 0);
	const setProgress = useWatch((state) => state.setProgress);
	const shell = (0, import_react.useRef)(null);
	const progressRef = (0, import_react.useRef)(saved > .98 ? 0 : saved);
	const [local, setLocal] = (0, import_react.useState)(progressRef.current);
	const [playing, setPlaying] = (0, import_react.useState)(true);
	const [seek, setSeek] = (0, import_react.useState)(0);
	const [chrome, setChrome] = (0, import_react.useState)(true);
	const [episodeIndex, setEpisodeIndex] = (0, import_react.useState)(episode);
	(0, import_react.useEffect)(() => {
		if (profileId === null && useWatch.persist.hasHydrated()) navigate({ to: "/" });
	}, [profileId, navigate]);
	(0, import_react.useEffect)(() => {
		setEpisodeIndex(episode);
	}, [episode]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		const origin = progressRef.current;
		const started = performance.now();
		let frame = 0;
		const tick = (now) => {
			const next = Math.min(1, origin + (now - started) / 1e3 / PREVIEW_SECONDS);
			progressRef.current = next;
			setLocal(next);
			if (next < 1) frame = requestAnimationFrame(tick);
			else setPlaying(false);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [
		playing,
		seek,
		episodeIndex
	]);
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setProgress(id, progressRef.current), 1e3);
		return () => {
			window.clearInterval(timer);
			setProgress(id, progressRef.current);
		};
	}, [id, setProgress]);
	(0, import_react.useEffect)(() => {
		if (!playing) {
			setChrome(true);
			return;
		}
		const timer = window.setTimeout(() => setChrome(false), 2600);
		return () => window.clearTimeout(timer);
	}, [
		playing,
		chrome,
		seek
	]);
	if (!title) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-bg-deep px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-semibold",
			children: "Judul ini tidak ada di rak."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-4 inline-flex h-11 items-center text-primary",
			children: "Kembali ke ADFLIX"
		})] })
	});
	const episodes = title.episodes ?? [];
	const currentEpisode = episodes.find((item) => item.n === episodeIndex) ?? episodes[0];
	const nextEpisode = episodes.find((item) => item.n === (currentEpisode?.n ?? 0) + 1);
	const jump = (value) => {
		const next = Math.min(1, Math.max(0, value));
		progressRef.current = next;
		setLocal(next);
		setSeek((count) => count + 1);
		setPlaying(true);
		setChrome(true);
	};
	const fullscreen = () => {
		const node = shell.current;
		if (!node) return;
		if (document.fullscreenElement) document.exitFullscreen();
		else node.requestFullscreen().catch(() => void 0);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: shell,
		className: "relative min-h-screen overflow-hidden bg-bg-deep text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: title.poster,
				alt: "",
				className: `absolute inset-0 h-full w-full object-cover ${playing ? "hero-drift" : ""}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg-deep via-bg-deep/25 to-bg-deep/50" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `absolute inset-0 flex flex-col transition-opacity duration-300 ${chrome ? "opacity-100" : "opacity-0"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-3 py-3 sm:px-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "grid size-11 place-items-center rounded-full bg-bg/70 ring-1 ring-line",
							"aria-label": "Kembali",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "text-2xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-sm text-fg sm:text-base",
								children: [title.name, currentEpisode ? ` · E${currentEpisode.n} ${currentEpisode.title}` : ""]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid flex-1 place-items-center",
						onClick: () => {
							setPlaying((value) => !value);
							setChrome(true);
						},
						"aria-label": playing ? "Jeda" : "Putar",
						children: playing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-20 place-items-center rounded-full bg-play text-play-fg shadow-xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-8 fill-current" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 pb-5 sm:px-8 sm:pb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between gap-3 text-xs text-muted sm:text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-card bg-bg/70 px-2 py-1 font-semibold tracking-wide text-fg uppercase",
									children: "Pratinjau"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: clock(local)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "group relative h-6 cursor-pointer",
								onClick: (event) => {
									const rect = event.currentTarget.getBoundingClientRect();
									jump((event.clientX - rect.left) / rect.width);
								},
								role: "slider",
								"aria-valuemin": 0,
								"aria-valuemax": 100,
								"aria-valuenow": Math.round(local * 100),
								"aria-label": "Garis waktu pratinjau",
								tabIndex: 0,
								onKeyDown: (event) => {
									if (event.key === "ArrowRight") jump(local + 10 / PREVIEW_SECONDS);
									if (event.key === "ArrowLeft") jump(local - 10 / PREVIEW_SECONDS);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-1/2 right-0 left-0 h-1 -translate-y-1/2 rounded-pill bg-line",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-pill bg-primary",
										style: { width: `${Math.round(local * 100)}%` }
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setPlaying((value) => !value),
										className: "grid size-11 place-items-center rounded-full bg-play text-play-fg",
										"aria-label": playing ? "Jeda" : "Putar",
										children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => jump(0),
										className: "grid size-11 place-items-center rounded-full bg-bg/70 ring-1 ring-line",
										"aria-label": "Dari awal",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
									}),
									local < .18 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => jump(.18),
										className: "h-11 rounded-md bg-bg/70 px-4 text-sm font-semibold ring-1 ring-line",
										children: "Lewati intro"
									}) : null,
									nextEpisode && local > .72 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setEpisodeIndex(nextEpisode.n);
											jump(0);
										},
										className: "inline-flex h-11 items-center gap-2 rounded-md bg-play px-4 text-sm font-bold text-play-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-4" }), "Episode berikutnya"]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-auto inline-flex items-center gap-2 text-xs text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }), "Tanpa suara"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: fullscreen,
										className: "grid size-11 place-items-center rounded-full bg-bg/70 ring-1 ring-line",
										"aria-label": "Layar penuh",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "size-4" })
									})
								]
							}),
							episodes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "no-scrollbar mt-4 flex gap-2 overflow-x-auto",
								children: episodes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setEpisodeIndex(item.n);
										jump(0);
									},
									className: `h-11 shrink-0 rounded-md px-3 text-sm ${item.n === (currentEpisode?.n ?? item.n) ? "bg-fg font-semibold text-play-fg" : "bg-bg/70 text-fg ring-1 ring-line"}`,
									children: [
										"E",
										item.n,
										" ",
										item.title
									]
								}, item.n))
							}) : null
						]
					})
				]
			}),
			!chrome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute inset-0",
				"aria-label": "Tampilkan kontrol",
				onClick: () => setChrome(true)
			}) : null
		]
	});
}
function WatchPage() {
	const { id } = Route.useParams();
	const { ep } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
		id,
		episode: ep
	});
}
//#endregion
export { WatchPage as component };
